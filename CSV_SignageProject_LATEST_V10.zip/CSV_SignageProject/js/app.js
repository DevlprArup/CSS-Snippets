/**
 * Created by Arup on 2/12/2015.
 */
(function (){
    "use strict";

    var app = angular.module("ScrollingApp", ['ngResource']);
    //
    //app.config(function($httpProvider){delete $httpProvider.defaults.headers.common['X-Requested-With'];});



}());
