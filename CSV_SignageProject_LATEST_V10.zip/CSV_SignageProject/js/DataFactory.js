/**
 * Created by Arup Home on 3/3/2015.
 */
(function (){
    "use strict";
    var app = angular.module('ScrollingApp');

    app.factory('DataFactory', factoryConstructor);


    function factoryConstructor($resource, $http){




        //var spreadSheetLink = "https://spreadsheets.google.com/feeds/list/1Kjm97OpOuYn4cqNqvGzJfl3-4XvSM4sP-mb0zK86Ws8/od6/public/values?alt=json-in-script&callback=?";
        var spreadSheetLink = "http://sites.mpmedia.tv/csvproject/getcsv.php";
        //var spreadSheetLink = "lib/events.json";

        return{

            getEventList: function () {
                //console.log("getEventList  CALLED");
                return $resource(spreadSheetLink);
                //return $resource("http://sites.mpmedia.tv/csvproject/getcsv.php");
            },

            getJqueryData: function (){
                //return $.getJSON("http://sites.mpmedia.tv/csvproject/getcsv.php?callback=");
                //return $.getJSON(spreadSheetLink);
            }


        }
    }
}());
