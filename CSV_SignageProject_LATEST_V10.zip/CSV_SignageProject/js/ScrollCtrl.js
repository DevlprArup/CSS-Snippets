/**
 * Created by Arup on 2/12/2015.
 */
(function () {
    "use strict";

    var app = angular.module ("ScrollingApp");

    app.controller ("ScrollCtrl", scrollControllerFunction)


    function scrollControllerFunction ($scope, $timeout, $rootScope, $element, $interval, $http, DataFactory) {

        jQuery.fx.interval = 12;

        //console.log(DataFactory);
        $scope.useArr = [];
        var listArr = [];
        var appStarted = false;
        $scope.showSection = false;
        var container = angular.element ($ ('.well'));
        var msgDiv = angular.element ($ ('.notification'));
        //
        var spinIcon = angular.element ($ ('.icn'));
        var speenTween = TweenMax.to (spinIcon, 0.9, {rotation: "360", repeat: -1, ease: Linear.easeInOut});
        //
        //$(".notification").hide();
        container.hide ();


        /*$http.jsonp("http://sites.mpmedia.tv/csvproject/getcsv.php?callback=JSON_CALLBACK")
         .success(function (data){
         console.log(data);
         })
         .error(function (){
         console.log('Error with JSONP');
         })*/


        /*DataFactory.getJqueryData ()
         .done (function (data) {
         console.log (data.feed.entry[0].gsx$eventstart['$t']);
         //modifyFetchedData (data);
         })
         .fail (function () {
         console.log ("Error Loading Spreadsheet data");
         });*/

        DataFactory.getEventList ().get (function (data) {
            //console.log (data.feed.entry);
            listArr = data.feed.entry;
            //console.log (listArr.length);
            //return;

            for (var i = 0; i < listArr.length; i++) {
                // Find Start Time
                var startTime = new Date (Date.parse (listArr[i].gsx$eventstart['$t']));
                if(i == 0){
                    //console.log(startTime);
                }
                startTime = startTime.toLocaleTimeString ();

                // Find End Time:
                var endTime = new Date (Date.parse (listArr[i].gsx$eventend['$t']));
                endTime = endTime.toLocaleTimeString ();


                //Update Start Time and End Time
                listArr[i].EventStart = startTime;
                listArr[i].EventEnd = endTime;
                //
                listArr[i].EventType = listArr[i].gsx$eventtype['$t'];
                listArr[i].CustName = listArr[i].gsx$custname['$t'];
                listArr[i].FacilityName = listArr[i].gsx$facilityname['$t'];
                //$scope.listArr[i].EventStart = (new Date(Date.parse($scope.listArr[i].EventStart)).toLocaleString());
                if (i == (listArr.length - 1)) {
                    console.log("startTime is :  "+listArr[i].EventStart);
                }
            }


            createUseArr ();


            //console.log("Here is the : "+$scope.listArr[4].EventStart);

        });

        function createUseArr () {
            $scope.useArr = listArr;

            console.log('createUseArr');
            //
            //angular.copy (listArr, $scope.useArr);

            container.show ('slow');
            msgDiv.hide ('slow');

            console.log($scope.useArr);
        }




        function modifyFetchedData (data) {

            //$scope.listArr = data.feed.entry;
            // Set time into required format:
            for (var i = 0; i < listArr.length; i++) {
                // Find Start Time
                var startTime = new Date (Date.parse (listArr[i].gsx$eventstart['$t']));
                startTime = startTime.toLocaleTimeString ();

                // Find End Time:
                var endTime = new Date (Date.parse (listArr[i].gsx$eventend['$t']));
                endTime = endTime.toLocaleTimeString ();


                //Update Start Time and End Time
                listArr[i].EventStart = startTime;
                listArr[i].EventEnd = endTime;
                //
                listArr[i].EventType = listArr[i].gsx$eventtype['$t'];
                listArr[i].CustName = listArr[i].gsx$custname['$t'];
                listArr[i].FacilityName = listArr[i].gsx$facilityname['$t'];
                //$scope.listArr[i].EventStart = (new Date(Date.parse($scope.listArr[i].EventStart)).toLocaleString());
                if (i == (listArr.length - 1)) {
                    //console.log("startTime is :  "+$scope.listArr[i].EventStart);
                    speenTween.pause ();
                    createUseArr ();
                }
            }

        }




        /*$http.get('lib/events.json').success(function(data) {
         console.log(data[0].gsx$eventstart['$t']);
         });*/
        /*
         $scope.listArr = [
         {CustName: 'University of Alabama Hockey Game', EventStart: '5:30:00',EventEnd:'7:30:00',EventType:'Free Style',FacilityName: 'Main Arena'},
         {CustName: 'North Ridge High School Ambassadors', EventStart: '7:45:00',EventEnd:'9:45:00',EventType:'Free Style',FacilityName: 'Practice Arena'},
         {CustName: 'BYHL', EventStart: '11:00:00',EventEnd:'13:00:00',EventType:'Public Skate',FacilityName: 'Test Arena'},
         {CustName: 'Riverchase Church of Christ', EventStart: '15:15:00',EventEnd:'17:15:00',EventType:'Broomball',FacilityName: 'Practice Arena'}];
         */

        ;





        //
        var intervalRef = $interval (intervalCallback, 3000);

        function intervalCallback () {
            /*var elem = angular.element($(ulGroup).firstElementChild);
             console.dir(elem);*/

            var elem = $ (".list-group li:first-child");

            elem.slideUp (600, function () {
                $ (this).appendTo (".list-group").fadeIn ();
            });
        }


        // For debug and dummy functionality

        //$timeout(hideScroll, 10000);


        function hideScroll () {
            $interval.cancel (intervalRef);
            $scope.showSection = true;
            //
            speenTween.play ();
            $ (".notification").slideDown ('slow');
            $ ('.well').slideUp ('slow', slideUpComplete);
        }

        function slideUpComplete () {
            // alert('Complete');
            //createUseArr ();
            //$timeout (pauseTimeOver, 6000);
        }


        function pauseTimeOver () {
            // After 6 seconds Pause time is over

            //TweenLite.to(msgDiv,1.8, {height:'0px', opacity: 0});
            speenTween.pause ();
            $ (".notification").slideUp ('slow');
            $ ('.well').slideDown ('slow', slideDownComplete);
        }

        function slideDownComplete () {
            intervalRef = $interval (intervalCallback, 3000);
        }


        // helper functions
        function getRandomArbitrary (min, max) {
            return Math.round (Math.random () * (max - min) + min);
        }

    }

} ());

